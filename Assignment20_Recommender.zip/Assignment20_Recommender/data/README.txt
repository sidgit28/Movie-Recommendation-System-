Place the Kaggle file tmdb_5000_movies.csv in this folder for the full assignment dataset.
Kaggle: https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata?select=tmdb_5000_movies.csv
demo_movies.csv is included only to let you run and test the app before downloading Kaggle data.
