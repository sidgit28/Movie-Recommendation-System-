# Assignment 20 — Building & Deploying a Content-Based Recommendation System

## Project overview

This project recommends movies based on content similarity. It combines each movie's genres, keywords, overview and tagline, cleans the combined text, converts it to TF-IDF vectors, and ranks other movies using cosine similarity. It does **not** use collaborative filtering or user ratings.

## Dataset

**Chosen Kaggle dataset:** TMDB 5000 Movie Dataset  
**Kaggle link:** https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata?select=tmdb_5000_movies.csv  
**Required file:** `tmdb_5000_movies.csv`  
**Required columns:** `title` and `overview`; the dataset also contains `genres`, `keywords`, and `tagline`.

The project includes `data/demo_movies.csv` with 20 clearly labelled example titles so you can run the app immediately. This is demo data, **not** the Kaggle dataset. To complete the dataset requirement, download `tmdb_5000_movies.csv` from Kaggle and place it in `data/`. The app automatically prefers the Kaggle CSV when present and otherwise warns that it is using demo data.

Before committing the Kaggle CSV to a public GitHub repository, review the dataset's licence/terms on Kaggle. If redistribution is not permitted or unclear, use a private repository or follow your instructor's approved method for making the data available to Render.

## Folder structure

```text
Assignment20_Recommender/
├── app.py
├── recommender.py
├── requirements.txt
├── README.md
├── render.yaml
├── .gitignore
└── data/
    ├── demo_movies.csv
    └── tmdb_5000_movies.csv   # download from Kaggle; not included
```

## Task mapping

1. **Load & understand data:** `app.py`/`recommender.py` read the CSV with Pandas and validate `title` and `overview`.
2. **Text preprocessing:** parse genres/keywords, fill missing values, lowercase text, remove punctuation/special characters and collapse spaces into `clean_text`.
3. **TF-IDF:** `TfidfVectorizer(stop_words="english", max_features=5000, ngram_range=(1, 2))`.
4. **Similarity:** cosine similarity compares a selected movie vector with all other movie vectors.
5. **Recommendation function:** `recommend_movies(movie_title, movies_df, tfidf_matrix, top_n=5)` returns the highest-scoring similar movies and excludes the selected movie itself.
6. **Streamlit UI:** choose a movie, set the number of recommendations and click the button.
7–9. **GitHub, Render and validation:** follow the steps below.

## Run locally in VS Code

1. Extract the ZIP and open this folder in VS Code.
2. (Recommended) Create and activate a virtual environment:

   ```bash
   python -m venv .venv
   ```

   Windows PowerShell:

   ```powershell
   .venv\Scripts\Activate.ps1
   ```

   macOS/Linux:

   ```bash
   source .venv/bin/activate
   ```

3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Run Streamlit:

   ```bash
   streamlit run app.py
   ```

5. Open the local URL printed in the terminal (usually `http://localhost:8501`).

## Git and GitHub setup

Create an empty repository on GitHub first. Then, in this project folder, run (replace the URL with your own repository URL):

```bash
git init
git add app.py recommender.py requirements.txt README.md render.yaml .gitignore data/demo_movies.csv
git commit -m "Build content-based movie recommendation app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

If the Kaggle CSV's licence allows committing it, also stage it with `git add data/tmdb_5000_movies.csv`. Otherwise, use a private repository or another instructor-approved data hosting approach. Never commit personal access tokens or passwords.

## Deploy on Render

1. Sign in to Render and connect your GitHub account.
2. Choose **New → Web Service** and select your repository.
3. Use these settings:
   - **Runtime:** Python 3
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `streamlit run app.py --server.address 0.0.0.0 --server.port $PORT`
4. Deploy and wait for the service status to become **Live**.
5. Open the generated `onrender.com` URL and test at least three different movies.

A `render.yaml` with these settings is included. If Render asks to configure fields manually, use the commands above. The app reads the `PORT` variable supplied by Render through the start command and binds to `0.0.0.0`.

**Data availability on Render:** The app needs the dataset file in the repository's `data/` folder at build/runtime. The demo CSV is included. For the full Kaggle catalogue, make the Kaggle CSV available to the deployed service in a way allowed by its licence (for example, commit it only if permitted).

## Validation checklist

- [ ] Downloaded and placed the Kaggle CSV in `data/`.
- [ ] Confirmed the app reports the Kaggle dataset rather than demo mode.
- [ ] Verified that `title` and `overview` columns exist.
- [ ] Tested at least three different selected titles.
- [ ] Confirmed recommendations do not include the selected movie itself.
- [ ] Pushed the project to GitHub.
- [ ] Deployed on Render and opened the live URL.
- [ ] Added the GitHub repository URL and deployed Render URL to the assignment submission.

## Notes

- This is a **content-based** recommender. It uses movie metadata, not user-item interactions.
- Cosine similarity compares vector direction, so it is useful for comparing TF-IDF text vectors of different lengths.
- The included 20-title CSV is only for immediate local testing. Use the Kaggle CSV for the actual assignment submission.
