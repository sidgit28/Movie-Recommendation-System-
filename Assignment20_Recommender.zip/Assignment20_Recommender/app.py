from pathlib import Path

import streamlit as st

from recommender import build_vectorizer, prepare_movies, recommend_movies

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
KAGGLE_DATA = DATA_DIR / "tmdb_5000_movies.csv"
DEMO_DATA = DATA_DIR / "demo_movies.csv"

st.set_page_config(page_title="Movie Recommender", page_icon="🎬", layout="centered")
st.title("🎬 Movie Recommendation System")
st.write("Choose a movie and discover other movies with similar genres, keywords and story descriptions.")


@st.cache_resource
def load_recommendation_data(data_path, file_modified_time):
    # Cache based on the path and modification time so a replaced CSV is reloaded.
    import pandas as pd
    raw = pd.read_csv(data_path)
    movies = prepare_movies(raw)
    vectorizer, tfidf_matrix = build_vectorizer(movies)
    return movies, vectorizer, tfidf_matrix


if KAGGLE_DATA.exists():
    selected_data_path = KAGGLE_DATA
    st.caption("Dataset: TMDB 5000 Movie Dataset (Kaggle)")
else:
    selected_data_path = DEMO_DATA
    st.info(
        "The full Kaggle CSV was not found, so the app is using the included 20-movie "
        "demo file. For your assignment submission, download `tmdb_5000_movies.csv` "
        "from Kaggle and place it in the `data` folder."
    )

try:
    movies, vectorizer, tfidf_matrix = load_recommendation_data(
        str(selected_data_path), selected_data_path.stat().st_mtime
    )

    st.caption(f"Loaded {len(movies):,} movies · {tfidf_matrix.shape[1]:,} TF-IDF features")
    title_options = movies["title"].tolist()
    selected_movie = st.selectbox("Select a movie", title_options)
    number_of_recommendations = st.slider("Number of recommendations", min_value=3, max_value=10, value=5)

    if st.button("Recommend Movies", type="primary"):
        results = recommend_movies(selected_movie, movies, tfidf_matrix, number_of_recommendations)
        st.subheader(f"Movies similar to {selected_movie}")
        if results.empty:
            st.warning("No recommendations were found for this movie.")
        else:
            for position, row in results.iterrows():
                st.markdown(f"**{position + 1}. {row['title']}**")
                if row["genres"]:
                    st.caption(f"Genres: {row['genres']}")
                st.progress(max(0.0, min(1.0, row["similarity"])))
                st.write(f"Similarity score: {row['similarity']:.3f}")
                st.divider()

    with st.expander("How does this recommender work?"):
        st.write(
            "The app combines each movie's genres, keywords, overview and tagline. "
            "TF-IDF converts this text into numerical vectors. Cosine similarity "
            "compares the selected movie vector with the other movie vectors. "
            "The app displays the highest-scoring titles, excluding the selected movie."
        )

except Exception as error:
    st.error(f"Could not load the movie dataset: {error}")
    st.markdown(
        "Check that the CSV has `title` and `overview` columns, and see the README "
        "for the correct Kaggle file and location."
    )
