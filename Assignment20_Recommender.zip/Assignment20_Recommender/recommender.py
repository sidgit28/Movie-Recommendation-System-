"""Reusable content-based movie recommendation helpers."""
from ast import literal_eval
import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def parse_names(value):
    """Extract the 'name' values from TMDB JSON-like genres/keywords cells."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    if isinstance(value, list):
        parsed = value
    else:
        try:
            parsed = literal_eval(str(value))
        except (ValueError, SyntaxError):
            return str(value)
    if isinstance(parsed, list):
        names = []
        for item in parsed:
            if isinstance(item, dict) and item.get("name"):
                names.append(str(item["name"]))
            elif isinstance(item, str):
                names.append(item)
        return " ".join(names)
    return str(parsed)


def clean_text(value):
    """Lowercase text and remove punctuation/symbols/extra whitespace."""
    text = "" if value is None or pd.isna(value) else str(value)
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def prepare_movies(raw_df):
    """Validate and combine overview, genre, keyword and tagline text."""
    required = {"title", "overview"}
    missing = required.difference(raw_df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")

    df = raw_df.copy()
    df["title"] = df["title"].fillna("").astype(str).str.strip()
    df["overview"] = df["overview"].fillna("").astype(str)

    for column in ("genres", "keywords"):
        if column not in df.columns:
            df[column] = ""
        df[column + "_text"] = df[column].apply(parse_names)

    if "tagline" not in df.columns:
        df["tagline"] = ""
    df["tagline"] = df["tagline"].fillna("").astype(str)

    # Genre and keyword fields add useful structured context to the overview.
    df["content_text"] = (
        df["genres_text"] + " " + df["keywords_text"] + " " +
        df["overview"] + " " + df["tagline"]
    )
    df["clean_text"] = df["content_text"].apply(clean_text)
    df = df[(df["title"] != "") & (df["clean_text"] != "")].copy()
    df = df.drop_duplicates(subset=["title"], keep="first").reset_index(drop=True)

    if len(df) < 2:
        raise ValueError("At least two movies with non-empty text are required.")
    return df


def build_vectorizer(movies_df, max_features=5000, ngram_range=(1, 2)):
    """Fit TF-IDF and return the vectorizer and sparse document matrix."""
    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=max_features,
        ngram_range=ngram_range,
        min_df=1,
    )
    matrix = vectorizer.fit_transform(movies_df["clean_text"])
    return vectorizer, matrix


def recommend_movies(movie_title, movies_df, tfidf_matrix, top_n=5):
    """Return the most similar movies, excluding the selected movie itself."""
    matches = movies_df.index[movies_df["title"].str.casefold() == str(movie_title).casefold()]
    if len(matches) == 0:
        raise ValueError(f"Movie not found: {movie_title}")

    selected_index = int(matches[0])
    scores = cosine_similarity(tfidf_matrix[selected_index], tfidf_matrix).ravel()
    ranked_indices = np.argsort(scores)[::-1]

    recommendations = []
    for index in ranked_indices:
        if index == selected_index:
            continue
        row = movies_df.iloc[int(index)]
        recommendations.append({
            "title": row["title"],
            "genres": row.get("genres_text", ""),
            "similarity": float(scores[index]),
        })
        if len(recommendations) >= max(1, int(top_n)):
            break

    return pd.DataFrame(recommendations)
